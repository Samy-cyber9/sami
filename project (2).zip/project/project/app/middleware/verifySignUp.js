const db = require("../models");
const ROLES = db.ROLES;
const User = db.user;

checkDuplicateUsernameOrEmail = (req, res, next) => {
  User.findOne({ username: req.body.username }).then((user) => {
    if (user)
      return res.status(400).send({ message: "Username is already in use!" });

    User.findOne({ email: req.body.email }).then((user) => {
      if (user)
        return res.status(400).send({ message: "Email is already in use!" });
      next();
    });
  });
};

checkRolesExisted = (req, res, next) => {
  if (req.body.roles) {
    for (let role of req.body.roles) {
      if (!ROLES.includes(role))
        return res
          .status(400)
          .send({ message: "Role does not exist: " + role });
    }
  }
  next();
};

module.exports = {
  checkDuplicateUsernameOrEmail,
  checkRolesExisted,
};
