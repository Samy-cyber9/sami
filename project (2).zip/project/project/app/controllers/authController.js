const User = require('../models/user.model');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

// Crée un token JWT
const createToken = (user) => {
  return jwt.sign(
    { id: user._id, role: user.role },
    'secret', // à sécuriser via variable d'environnement
    { expiresIn: '1h' }
  );
};

exports.register = async (req, res) => {
  try {
    const { username, email, password, role } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ username, email, password: hashedPassword, role });
    await newUser.save();
    res.status(201).json({ message: 'Utilisateur créé avec succès' });
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de l’enregistrement' });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: 'Utilisateur introuvable' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ message: 'Mot de passe incorrect' });

    const token = createToken(user);
    res.cookie('token', token, { httpOnly: true }).json({ message: 'Connecté', role: user.role });
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de la connexion' });
  }
};
