const Lesson = require('../models/Lesson');
const Course = require('../models/Course');

exports.addLesson = async (req, res) => {
  try {
    const { title, content, courseId } = req.body;
    const lesson = new Lesson({ title, content, courseId });
    await lesson.save();

    await Course.findByIdAndUpdate(courseId, { $push: { lessons: lesson._id } });
    res.status(201).json(lesson);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.getLessonsByCourse = async (req, res) => {
  const lessons = await Lesson.find({ courseId: req.params.courseId });
  res.json(lessons);
};
