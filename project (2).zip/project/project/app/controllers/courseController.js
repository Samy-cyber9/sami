const Course = require('../models/Course');

exports.createCourse = async (req, res) => {
  try {
    const course = new Course({ ...req.body, teacherId: req.user.id });
    await course.save();
    res.status(201).json(course);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.getCourses = async (req, res) => {
  const courses = await Course.find().populate('teacherId', 'username');
  res.json(courses);
};
