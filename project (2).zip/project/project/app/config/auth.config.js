module.exports = {
    secret: "e-learning-secret-key"
  };