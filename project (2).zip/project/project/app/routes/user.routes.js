const authJwt = require("../middleware/authMiddleware");
const controller = require("../controllers/user.controller");

module.exports = function (app) {
  app.get("/api/user/student", [authJwt.verifyToken], controller.studentBoard);

  app.get(
    "/api/user/teacher",
    [authJwt.verifyToken, authJwt.isTeacher],
    controller.teacherBoard
  );

  app.get(
    "/api/user/admin",
    [authJwt.verifyToken, authJwt.isAdmin],
    controller.adminBoard
  );
};
