const express = require('express');
const router = express.Router();
const { addLesson, getLessonsByCourse } = require('../controllers/lessonController');
const { verifyToken, allowRoles } = require('../middleware/authMiddleware');

router.post('/', verifyToken, allowRoles('teacher', 'admin'), addLesson);
router.get('/:courseId', verifyToken, getLessonsByCourse);

module.exports = router;
