const express = require('express');
const router = express.Router();
const { createCourse, getCourses } = require('../controllers/courseController');
const { verifyToken, allowRoles } = require('../middleware/authMiddleware');

router.post('/', verifyToken, allowRoles('teacher', 'admin'), createCourse);
router.get('/', verifyToken, getCourses);

module.exports = router;
