const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const path = require('path');

const authRoutes = require('./app/routes/authRoutes');
const courseRoutes = require('./app/routes/courseRoutes');
const lessonRoutes = require('./app/routes/lessonRoutes');

const { verifyToken } = require('./app/middleware/authMiddleware');

const app = express();
const PORT = 3000;

// Middlewares globaux
app.use(cors());
app.use(express.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// Routes API
app.use('/api/auth', authRoutes);
app.use('/api/courses', verifyToken, courseRoutes);  // <-- protection par token JWT
app.use('/api/lessons', verifyToken, lessonRoutes);  // <-- protection par token JWT

// Routes HTML
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.get('/register', (req, res) => res.sendFile(path.join(__dirname, 'public', 'register.html')));
app.get('/dashboardStudent', (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboardStudent.html')));
app.get('/dashboardTeacher', (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboardTeacher.html')));
app.get('/dashboardAdmin', (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboardAdmin.html')));

// Connexion à MongoDB et démarrage du serveur
mongoose.connect('mongodb://127.0.0.1:27017/elearning')
  .then(() => {
    console.log('MongoDB connected');
    app.listen(PORT, () => {
      console.log(`Server started on http://localhost:${PORT}`);
    });
  })
  .catch(err => console.error('MongoDB connection error:', err));
